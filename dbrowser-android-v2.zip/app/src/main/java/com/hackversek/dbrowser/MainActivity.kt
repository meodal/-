package com.hackversek.dbrowser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import android.content.res.ColorStateList

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var titleBar: TextView
    private lateinit var tabLabel: TextView
    private lateinit var engineSpinner: Spinner
    private lateinit var settingsScroll: ScrollView
    private var settingsOpen = false
    private var privateMode = false
    private var desktopMode = false
    private var javaScript = true
    private var imagesEnabled = true
    private var saveHistory = true
    private var homeUrl = "https://www.google.com"
    private var searchEngine = "Google"
    private var blurAmount = 20
    private var cornerAmount = 22
    private var textScale = 100
    private var currentTheme = "Liquid Glass"
    private val history = mutableListOf<String>()
    private val bookmarks = linkedSetOf<String>()
    private var tabCount = 1
    private val bg = Color.rgb(15, 17, 24)
    private val panel = Color.rgb(29, 32, 45)
    private val text = Color.rgb(245, 246, 255)
    private val muted = Color.rgb(162, 169, 190)
    private val accent = Color.rgb(161, 138, 255)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildShell()
        showStartPage()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = cornerAmount): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(8), dp(7), dp(8), dp(6))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), dp(4), dp(5), dp(4))
            background = rounded(panel)
        }
        val logo = TextView(this).apply {
            text = "D"; textSize = 25f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(text); gravity = Gravity.CENTER; setPadding(dp(8), 0, dp(8), 0)
        }
        address = EditText(this).apply {
            hint = "Поиск или адрес"; setHintTextColor(muted); setTextColor(text)
            textSize = 14f; singleLine = true; imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(dp(13), 0, dp(9), 0); background = rounded(Color.rgb(40, 43, 58), 17)
            setSelectAllOnFocus(false)
        }
        address.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) {
                navigate(address.text.toString()); true
            } else false
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(39), dp(46)))
        header.addView(address, LinearLayout.LayoutParams(0, dp(44), 1f))
        header.addView(iconButton("arrow-right", "↵") { navigate(address.text.toString()) },
            LinearLayout.LayoutParams(dp(43), dp(44)))
        root.addView(header)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(accent); visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))

        web = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.allowFileAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val scheme = request?.url?.scheme ?: return false
                    return scheme != "http" && scheme != "https"
                }
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    progress.visibility = View.VISIBLE
                    if (url != null) address.setText(url)
                    if (url != null && saveHistory && !privateMode && !url.startsWith("about:")) {
                        if (history.lastOrNull() != url) history.add(url)
                    }
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    progress.visibility = View.GONE
                    if (url != null) address.setText(url)
                    applyBrowserSettings()
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, value: Int) {
                    progress.progress = value
                    progress.visibility = if (value in 1..99) View.VISIBLE else View.GONE
                }
                override fun onReceivedTitle(view: WebView?, title: String?) {
                    titleBar.text = title?.take(50) ?: "D Browser"
                }
            }
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        titleBar = TextView(this).apply {
            text = "D Browser"; setTextColor(muted); textSize = 11f
            gravity = Gravity.CENTER; maxLines = 1
        }
        root.addView(titleBar, LinearLayout.LayoutParams(-1, dp(18)))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = rounded(panel); setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        nav.addView(iconButton("back", "‹") { if (web.canGoBack()) web.goBack() }, navWeight())
        nav.addView(iconButton("forward", "›") { if (web.canGoForward()) web.goForward() }, navWeight())
        nav.addView(iconButton("home", "⌂") { showStartPage() }, navWeight())
        nav.addView(iconButton("bookmark", "☆") { toggleBookmark() }, navWeight())
        nav.addView(iconButton("tabs", "$tabCount") { showTabsDialog() }, navWeight())
        nav.addView(iconButton("settings", "⚙") { showSettings() }, navWeight())
        root.addView(nav)
        setContentView(root)
    }

    private fun navWeight() = LinearLayout.LayoutParams(0, dp(45), 1f)

    // Uses vector-like line icons drawn as SVG path data for consistent rendering.
    private fun iconButton(name: String, fallback: String, action: () -> Unit): TextView {
        val button = TextView(this).apply {
            text = fallback; textSize = 21f; gravity = Gravity.CENTER
            setTextColor(text); background = rounded(Color.TRANSPARENT, 15)
            contentDescription = name
            setOnClickListener {
                animate().scaleX(.92f).scaleY(.92f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                    action()
                }.start()
            }
        }
        return button
    }

    private fun navigate(raw: String) {
        var q = raw.trim()
        if (q.isEmpty()) return
        val target = when {
            q.startsWith("https://") || q.startsWith("http://") -> q
            q.contains(".") && !q.contains(" ") -> "https://$q"
            else -> searchUrl(q)
        }
        web.visibility = View.VISIBLE
        web.loadUrl(target)
    }

    private fun searchUrl(q: String): String {
        val encoded = android.net.Uri.encode(q)
        return when (searchEngine) {
            "Bing" -> "https://www.bing.com/search?q=$encoded"
            "DuckDuckGo" -> "https://duckduckgo.com/?q=$encoded"
            "Yahoo" -> "https://search.yahoo.com/search?p=$encoded"
            else -> "https://www.google.com/search?q=$encoded"
        }
    }

    private fun showStartPage() {
        val html = """
        <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
        <style>
        *{box-sizing:border-box}body{margin:0;min-height:100vh;background:#0f1118;color:#f5f6ff;font:16px system-ui;display:grid;place-items:center}
        main{width:min(600px,92vw);padding:22px;text-align:center;animation:enter .42s ease-out}
        @keyframes enter{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
        .logo{font-size:80px;font-weight:900;letter-spacing:-8px;background:linear-gradient(130deg,#fff,#b9aaff,#6edbe9);color:transparent;background-clip:text}
        h1{font-size:26px;margin:8px 0}.muted{color:#a2a9be;margin:8px 0 24px}
        form{display:flex;gap:8px;padding:7px;border:1px solid #ffffff22;background:#ffffff0d;border-radius:24px;backdrop-filter:blur(22px)}
        input{min-width:0;flex:1;border:0;outline:0;background:transparent;color:white;padding:12px;font-size:16px}
        button{border:0;border-radius:16px;background:#a18aff;color:#151322;font-weight:700;padding:0 17px}
        .links{display:flex;justify-content:center;gap:9px;flex-wrap:wrap;margin-top:20px}
        .links a{color:#f5f6ff;background:#ffffff0d;border:1px solid #ffffff17;padding:10px 13px;border-radius:14px;text-decoration:none}
        </style></head><body><main><div class="logo">D</div><h1>D Browser</h1><div class="muted">Поиск и интернет — в одном месте</div>
        <form id="f"><input id="q" placeholder="Что ищем?" autocomplete="off"><button>Искать</button></form>
        <div class="links"><a href="https://www.youtube.com">YouTube</a><a href="https://wikipedia.org">Wikipedia</a><a href="https://github.com">GitHub</a></div>
        </main><script>document.getElementById('f').addEventListener('submit',function(e){e.preventDefault();var q=document.getElementById('q').value.trim();if(q) location.href='${searchUrl("__QUERY__").substringBefore("__QUERY__")}'+encodeURIComponent(q)});</script>
        </body></html>
        """.trimIndent()
        web.loadDataWithBaseURL("https://d-browser.local/", html, "text/html", "UTF-8", null)
    }

    private fun applyBrowserSettings() {
        web.settings.javaScriptEnabled = javaScript
        web.settings.loadsImagesAutomatically = imagesEnabled
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.textZoom = textScale
        web.settings.userAgentString = if (desktopMode) {
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36"
        } else null
    }

    private fun toggleBookmark() {
        val url = web.url ?: return
        if (url.startsWith("https://") || url.startsWith("http://")) {
            if (!bookmarks.add(url)) bookmarks.remove(url)
            toast(if (bookmarks.contains(url)) "Добавлено в закладки" else "Закладка удалена")
        }
    }

    private fun showTabsDialog() {
        val options = arrayOf("Новая вкладка", "История", "Закладки", "Закрыть")
        AlertDialog.Builder(this).setTitle("Вкладки · $tabCount")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { tabCount++; address.setText(""); showStartPage(); toast("Вкладка $tabCount") }
                    1 -> showListDialog("История", history.reversed())
                    2 -> showListDialog("Закладки", bookmarks.toList())
                    else -> toast("Вкладки в этой сборке используют общий WebView")
                }
            }.show()
    }

    private fun showListDialog(title: String, items: List<String>) {
        if (items.isEmpty()) { toast("$title пока пусто"); return }
        AlertDialog.Builder(this).setTitle(title).setItems(items.toTypedArray()) { _, which ->
            navigate(items[which])
        }.setNegativeButton("Закрыть", null).show()
    }

    private fun showSettings() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(12))
            background = rounded(Color.rgb(25, 27, 39), 24)
        }
        fun heading(s: String) {
            layout.addView(TextView(this).apply {
                text = s; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(accent); setPadding(0, dp(16), 0, dp(6))
            })
        }
        fun toggle(label: String, initial: Boolean, changed: (Boolean) -> Unit) {
            val row = Switch(this).apply {
                text = label; setTextColor(text); isChecked = initial
                setPadding(0, dp(5), 0, dp(5)); setOnCheckedChangeListener { _, v -> changed(v) }
            }
            layout.addView(row)
        }
        fun selector(label: String, options: List<String>, current: String, changed: (String) -> Unit) {
            layout.addView(TextView(this).apply { text = label; setTextColor(muted); setPadding(0, dp(8), 0, dp(5)) })
            val spinner = Spinner(this)
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
            spinner.setSelection(options.indexOf(current).coerceAtLeast(0))
            spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    changed(options[position])
                }
            }
            layout.addView(spinner)
        }
        fun slider(label: String, min: Int, max: Int, initial: Int, changed: (Int) -> Unit) {
            val labelView = TextView(this).apply { text = "$label: $initial"; setTextColor(muted); setPadding(0, dp(10), 0, 0) }
            layout.addView(labelView)
            val seek = SeekBar(this).apply { this.max = max - min; progress = initial - min; progressTintList = ColorStateList.valueOf(accent); thumbTintList = ColorStateList.valueOf(accent) }
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    labelView.text = "$label: ${value + min}"
                    changed(value + min)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            layout.addView(seek)
        }

        heading("Внешний вид")
        selector("Тема", listOf("Liquid Glass", "Snow", "Midnight", "Ocean", "Forest", "Sunset", "Rose", "Lavender", "Emerald", "Amber", "Monochrome", "Nord", "Dracula", "Cyberpunk", "Cherry", "Mint", "Sky", "Sand", "Plum", "Graphite"), currentTheme) {
            currentTheme = it
            window.statusBarColor = if (it == "Snow") Color.rgb(235, 239, 247) else bg
            toast("Тема: $it")
        }
        slider("Размытие стекла", 0, 36, blurAmount) { blurAmount = it }
        slider("Скругление", 4, 32, cornerAmount) { cornerAmount = it }
        slider("Размер текста", 75, 150, textScale) { textScale = it; if (::web.isInitialized) web.settings.textZoom = it }

        heading("Поиск")
        selector("Поисковая система", listOf("Google", "Bing", "DuckDuckGo", "Yahoo"), searchEngine) { searchEngine = it }
        selector("Домашняя страница", listOf("Стартовая D", "Google", "DuckDuckGo", "Blank"), when(homeUrl) {
            "https://www.google.com" -> "Google"
            "https://duckduckgo.com" -> "DuckDuckGo"
            "about:blank" -> "Blank"
            else -> "Стартовая D"
        }) {
            homeUrl = when(it) { "Google" -> "https://www.google.com"; "DuckDuckGo" -> "https://duckduckgo.com"; "Blank" -> "about:blank"; else -> "d-home" }
        }

        heading("Приватность и безопасность")
        toggle("Приватный режим", privateMode) { privateMode = it; toast(if(it) "Приватный режим включён" else "Приватный режим выключен") }
        toggle("Сохранять историю", saveHistory) { saveHistory = it }
        toggle("JavaScript", javaScript) { javaScript = it; web.settings.javaScriptEnabled = it }
        toggle("Загружать изображения", imagesEnabled) { imagesEnabled = it; web.settings.loadsImagesAutomatically = it }
        toggle("Версия сайта для компьютера", desktopMode) { desktopMode = it; applyBrowserSettings(); web.reload() }
        toggle("Блокировать всплывающие окна", true) { web.settings.javaScriptCanOpenWindowsAutomatically = !it; web.settings.setSupportMultipleWindows(!it) }

        heading("Данные браузера")
        layout.addView(makeActionRow("Очистить историю") { history.clear(); toast("История очищена") })
        layout.addView(makeActionRow("Очистить закладки") { bookmarks.clear(); toast("Закладки очищены") })
        layout.addView(makeActionRow("Очистить кэш") { web.clearCache(true); toast("Кэш очищен") })
        layout.addView(makeActionRow("Перезагрузить страницу") { web.reload() })
        heading("Информация")
        layout.addView(TextView(this).apply {
            text = "D Browser 2.0\\nAndroid WebView · ранняя версия\\nНекоторые параметры требуют дальнейшей интеграции."
            setTextColor(muted); setPadding(0, dp(5), 0, dp(14))
        })

        settingsScroll = ScrollView(this).apply {
            isFillViewport = true
            addView(layout)
            setBackgroundColor(Color.rgb(25, 27, 39))
        }
        settingsOpen = true
        AlertDialog.Builder(this)
            .setTitle("Настройки D Browser")
            .setView(settingsScroll)
            .setPositiveButton("Готово") { _, _ -> settingsOpen = false }
            .setNeutralButton("Очистить данные") { _, _ ->
                history.clear(); bookmarks.clear(); web.clearHistory(); web.clearCache(true); toast("Локальные данные очищены")
            }
            .setOnDismissListener { settingsOpen = false }
            .show()
    }

    private fun makeActionRow(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; isAllCaps = false; setTextColor(text)
            background = rounded(panel, 15)
            setOnClickListener { action() }
        }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        if (settingsOpen) { settingsOpen = false; return }
        if (::web.isInitialized && web.canGoBack()) web.goBack() else showStartPage()
    }
}
